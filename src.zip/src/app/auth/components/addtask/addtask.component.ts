import { Component, OnInit, Output ,EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms'; 

@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {

  @Output() tableDataValues=new EventEmitter<string>();  
  constructor() { }  
  ngOnInit() {  
  }  
  Priority = ['Low', 'Medium', 'High', 'Urgent'];  
  assignees = ['Self', 'Manager', 'Team Lead', 'IT team'];
  SubmitForm(regisForm:NgForm){  
  this.tableDataValues.emit(regisForm.value);  
  }  
  }  
