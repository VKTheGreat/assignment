import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import {Router} from '@angular/router'; 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @Input() item :any;  
  @Output() deleteItem = new EventEmitter<string>(); 
  constructor(private router: Router) { }

  clickMe() {  
    this.router.navigate(['/ticket_list/add'])  
} 
  ngOnInit(): void {
  }
  deleteCard(val: string) {  
    this.deleteItem.emit(val);  
    }  
    }  
