import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SserviceService } from '../../auth/sservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  LoginForm = new FormGroup({
    email: new FormControl(''),
    password : new FormControl(''),
  })

  constructor(private auth: SserviceService, private router: Router) { }
  
  ngOnInit(): void {
     if (this.auth.isLoggedIn()) {
      this.router.navigate(['/ticket_list']); 
     } 
  }
  submit(): void {
    if (this.LoginForm.valid) {
      this.auth.login(this.LoginForm.value).subscribe(
        (result) => {
          console.log(result);
          this.router.navigate(['/ticket_list']);
        },
        (err: Error) => {
          alert(err.message);
        }
      );
    }
  }
}
