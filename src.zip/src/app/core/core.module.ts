import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { NotFoundComponent } from './not-found/not-found.component';
import {PasswordModule} from 'primeng/password';
import {FormsModule} from '@angular/forms';
import {CheckboxModule} from 'primeng/checkbox';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    LoginComponent,
    ForgotPasswordComponent,
    NotFoundComponent
  ],
  imports: [
    CommonModule,
    PasswordModule,
    FormsModule,
    CheckboxModule,
    RouterModule,
    ReactiveFormsModule
  ]
})
export class CoreModule { 
  
}
