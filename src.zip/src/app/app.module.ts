import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { LoginComponent } from 'src/app/core/login/login.component';
import { ForgotPasswordComponent } from 'src/app/core/forgot-password/forgot-password.component';
import { NotFoundComponent } from 'src/app/core/not-found/not-found.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TicketListComponent } from './auth/ticket-list/ticket-list.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { HeaderComponent } from './auth/components/header/header.component';
import { FooterComponent } from './auth/components/footer/footer.component';
import { HomeComponent } from './auth/components/home/home.component';
import { AboutComponent } from './auth/components/about/about.component';
import { ContactComponent } from './auth/components/contact/contact.component';
import { ServicesComponent } from './auth/components/services/services.component';
import { AddtaskComponent } from './auth/components/addtask/addtask.component';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AppComponent, 
    LoginComponent,
    ForgotPasswordComponent,
    NotFoundComponent,
    TicketListComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    ServicesComponent,
    AddtaskComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule,
ReactiveFormsModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
