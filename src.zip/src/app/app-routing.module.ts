import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from './core/login/login.component';
import { ForgotPasswordComponent } from './core/forgot-password/forgot-password.component';
import { NotFoundComponent } from './core/not-found/not-found.component';
import { GuardGuard } from './auth/guard.guard';
/* import { TicketListComponent } from './auth/ticket-list/ticket-list.component'; 
import { AdminModule } from './auth/admin/admin.module'; */

const routes: Routes = [
  {path:'login', component: LoginComponent},
  {path:'forgot-password', component: ForgotPasswordComponent},
  {path:'ticket_list', 
  canActivate:[GuardGuard],
  loadChildren:()=> import('./auth/admin/admin.module').then((m)=>m.AdminModule)}, 
  {path:'', redirectTo: '/login', pathMatch:'full'},
  {path:'**', component:NotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
